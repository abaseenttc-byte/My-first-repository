const JSON_HEADERS = {"content-type":"application/json; charset=utf-8","cache-control":"no-store"};
function json(data,status=200,headers={}){return new Response(JSON.stringify(data),{status,headers:{...JSON_HEADERS,...headers}})}
function b64(bytes){let s="";for(const b of new Uint8Array(bytes))s+=String.fromCharCode(b);return btoa(s)}
async function sha256(s){return b64(await crypto.subtle.digest("SHA-256",new TextEncoder().encode(s)))}
async function sign(payload,secret){const key=await crypto.subtle.importKey("raw",new TextEncoder().encode(secret),{name:"HMAC",hash:"SHA-256"},false,["sign"]);return b64(await crypto.subtle.sign("HMAC",key,new TextEncoder().encode(payload)))}
async function makeToken(secret){const payload=btoa(JSON.stringify({sub:"admin",exp:Date.now()+8*60*60*1000}));return payload+"."+await sign(payload,secret)}
async function authorized(request,env){const header=request.headers.get("authorization")||"";const token=header.startsWith("Bearer ")?header.slice(7):"";const [payload,sig]=token.split(".");if(!payload||!sig||!env.SESSION_SECRET)return false;const expected=await sign(payload,env.SESSION_SECRET);if(sig!==expected)return false;try{const p=JSON.parse(atob(payload));return p.sub==="admin"&&p.exp>Date.now()}catch{return false}}
function clean(s,max=5000){return typeof s==="string"?s.trim().slice(0,max):""}
async function parseBody(request){try{return await request.json()}catch{return null}}
export async function onRequest({request,env}) {
 const url=new URL(request.url), path=url.pathname.replace(/^\/api/,"");
 if(request.method==="OPTIONS")return new Response(null,{status:204,headers:{"access-control-allow-origin":"same-origin","access-control-allow-methods":"GET,POST,DELETE,OPTIONS","access-control-allow-headers":"Content-Type,Authorization"}});
 if(path==="/login"&&request.method==="POST"){
  if(!env.ADMIN_USERNAME||!env.ADMIN_PASSWORD_HASH||!env.SESSION_SECRET)return json({error:"Admin is not configured. Set ADMIN_USERNAME, ADMIN_PASSWORD_HASH and SESSION_SECRET in Cloudflare Pages secrets."},503);
  const body=await parseBody(request);if(!body)return json({error:"Invalid request."},400);
  if(clean(body.username,100)!==env.ADMIN_USERNAME)return json({error:"Invalid username or password."},401);
  const supplied=await sha256(clean(body.password,500));if(supplied!==env.ADMIN_PASSWORD_HASH)return json({error:"Invalid username or password."},401);
  return json({token:await makeToken(env.SESSION_SECRET)});
 }
 if(path==="/jobs"&&request.method==="GET"){
  if(!env.DB)return json({jobs:[]});
  const all=url.searchParams.get("all")==="1"&&await authorized(request,env);
  if(url.searchParams.get("all")==="1"&&!all)return json({error:"Sign in again to continue."},401);
  const sql=all?"SELECT id,title,country,salary,positions,category,deadline,description,status,created_at FROM jobs ORDER BY created_at DESC":"SELECT id,title,country,salary,positions,category,deadline,description,status,created_at FROM jobs WHERE status='published' ORDER BY created_at DESC";
  const {results=[]}=await env.DB.prepare(sql).all();return json({jobs:results});
 }
 if(path==="/jobs"&&request.method==="POST"){
  if(!await authorized(request,env))return json({error:"Please sign in again."},401);
  if(!env.DB)return json({error:"Database binding DB is missing."},503);
  const b=await parseBody(request);if(!b)return json({error:"Invalid request."},400);
  const title=clean(b.title,140),country=clean(b.country,100),description=clean(b.description,5000),status=b.status==="draft"?"draft":"published";
  if(!title||!country||!description)return json({error:"Title, country and job details are required."},400);
  const id=crypto.randomUUID(), now=new Date().toISOString();
  await env.DB.prepare("INSERT INTO jobs (id,title,country,salary,positions,category,deadline,description,status,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)").bind(id,title,country,clean(b.salary,100),clean(b.positions,40),clean(b.category,100),clean(b.deadline,20),description,status,now).run();
  return json({ok:true,id},201);
 }
 const match=path.match(/^\/jobs\/([0-9a-f-]+)$/i);
 if(match&&request.method==="DELETE"){
  if(!await authorized(request,env))return json({error:"Please sign in again."},401);
  if(!env.DB)return json({error:"Database binding DB is missing."},503);
  await env.DB.prepare("DELETE FROM jobs WHERE id=?").bind(match[1]).run();return json({ok:true});
 }
 return json({error:"Not found."},404);
}