# New Abaseen TTC — Cloudflare Pages starter

## What's included
- `public/`: bilingual public business profile site, supplied logo, live published-jobs section, WhatsApp enquiry links.
- `public/admin/index.html`: admin sign-in, create/publish/draft/delete job posts.
- `functions/api/[[path]].js`: Cloudflare Pages Functions API.
- `schema.sql` and `migrations/0001_create_jobs.sql`: Cloudflare D1 database schema.
- `wrangler.toml`: Cloudflare Pages/D1 configuration template.

## Important
This is a deployable starter, not a website already published online. You must create the Cloudflare resources and set secrets before the admin API will work. Never put admin passwords or secret keys in public HTML or Git.

## Recommended deployment steps

1. Register `newabaseen.com` with a domain registrar. Check availability and price at purchase time; this package does not buy the domain.
2. Create/sign in to a Cloudflare account and add `newabaseen.com` as a site. Follow Cloudflare's nameserver instructions at the registrar.
3. In Cloudflare Dashboard, create a D1 database named `new-abaseen-jobs`. Run `schema.sql` in its SQL console. Copy the database ID into `wrangler.toml` where the placeholder appears.
4. Create a Pages project from a GitHub repository containing these files. Build command can be left blank for this static site; set build output directory to `public`. Cloudflare Pages Functions in the root `functions/` folder are deployed with the Pages project.
5. In Pages > Settings > Bindings, add a D1 database binding named `DB` pointing to `new-abaseen-jobs`.
6. In Pages > Settings > Variables and Secrets, add:
   - `ADMIN_USERNAME`: choose a unique admin username.
   - `ADMIN_PASSWORD_HASH`: SHA-256 base64 digest of the password. Generate locally with the Node command below, and use a strong, unique password.
   - `SESSION_SECRET`: a long random secret, at least 32 random bytes, base64 encoded.
   Set these as secrets where Cloudflare offers secret values. Never put actual values in source control.
7. Generate password hash locally with Node.js:
   `node -e "const c=require('crypto');process.stdout.write(c.createHash('sha256').update(process.argv[1]).digest('base64'))" 'YOUR-STRONG-PASSWORD'`
   Avoid reusing this example password; replace it with your own.
   Generate a session secret with:
   `node -e "console.log(require('crypto').randomBytes(48).toString('base64'))"`
8. Deploy the Pages project. Test `/`, `/jobs` (jobs section), `/admin/` (sign-in), and create a draft test listing. Then publish a test listing and verify it appears publicly.
9. In Pages > Custom domains, add `newabaseen.com` and follow Cloudflare's DNS instructions. Add `www.newabaseen.com` too if you want the www version.
10. Before public launch, test on mobile, verify contact details, add privacy/terms notices if collecting personal data, and have a qualified developer review security. The contact form on the current public page opens WhatsApp and does not store enquiries in a database.

## Admin usage
Open `https://newabaseen.com/admin/`, sign in, complete the job form, and choose Publish or Draft. Published jobs show on the public page; drafts are admin-only. Sign-out clears the browser's session token.

## Notes / limitations
- This starter uses a simple bearer session token stored in sessionStorage and SHA-256 password-hash comparison. For a public production recruitment portal, have a developer upgrade authentication to a mature identity provider or secure password hashing (Argon2id/bcrypt), add rate limiting/Cloudflare Turnstile, audit logging, backups, and input validation.
- No online application submission or candidate-document upload/storage is implemented yet. Add this separately only after deciding privacy, retention, and access controls.
- Contact phone, location and email are editable in `public/index.html`; check them before publishing.
